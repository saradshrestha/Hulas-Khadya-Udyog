<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductRecpie extends Model
{
    //
}
