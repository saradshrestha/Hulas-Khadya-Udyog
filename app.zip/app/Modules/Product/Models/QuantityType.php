<?php

namespace Product\Models;

use Illuminate\Database\Eloquent\Model;

class QuantityType extends Model
{

    protected $fillable = ['title', 'decription'];
}
