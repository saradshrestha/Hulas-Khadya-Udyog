@extends('admin.partials.master')

@push('styles')

@endpush

@section('contents')

@endsection

@push('scripts')

@endpush
