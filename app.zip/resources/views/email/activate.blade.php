Activate your account by clicking <a href="{{ route('user.activate', [$user->id, $code]) }}">here</a>
