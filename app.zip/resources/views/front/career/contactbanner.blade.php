<div class = "contact-hero-wrapper d-flex align-items-center">
    <div class = "container px-0">
        <div class = "contact-hero">
            <div class = "row">
                <div class = "offset-lg-6 col-lg-6">
                    <div class = "contact-hero-title text-center text-lg-start">
                        <h3 class = "fw-3 fs-48 text-uppercase my-0">contact us</h3>
                        <p class = "fw-5 fs-20">SKYWORTH support is just a call, chat or email away.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>