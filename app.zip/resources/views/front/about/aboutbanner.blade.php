<div class = "about-hero-wrapper d-flex align-items-center" 
    style=" background: url('{{('frontendFiles/assets/images/pg-about/about-hero-img.png')}}') center/cover no-repeat;
    min-height: 325px;">

    {{-- asset('frontendFiles/assets/images/pg-about/about-hero-img.png') --}}
    <div class = "container px-0">
        <div class = "about-hero">
            <div class = "row">
                <div class = "offset-lg-6 col-lg-6">
                    <div class = "about-hero-title text-center text-lg-start">
                        <h3 class = "fw-3 text-uppercase" style="font-size:36px;">about skyworth</h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>