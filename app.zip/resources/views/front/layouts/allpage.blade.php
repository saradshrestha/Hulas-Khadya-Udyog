@extends('front.layouts.master')

@push('styles')

@endpush



@section('content')

@endsection

@push('scripts')

@endpush